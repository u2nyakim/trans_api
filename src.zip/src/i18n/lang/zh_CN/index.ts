/**
 * 简体中文
 */
import route from './route';
import layout from './layout';
import login from './login';
import list from './list';

export default {
  route,
  layout,
  login,
  list
};
