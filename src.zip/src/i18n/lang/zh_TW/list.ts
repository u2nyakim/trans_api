/* 列表页面 */
export default {
  // 基础列表
  basic: {
    table: {
      avatar: '頭像',
      username: '用戶賬號',
      nickname: '用戶名',
      organizationName: '組織機構',
      phone: '手機號',
      sexName: '性別',
      createTime: '創建時間',
      status: '狀態',
      action: '操作'
    }
  }
};
