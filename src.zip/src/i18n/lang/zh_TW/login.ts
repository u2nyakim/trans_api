/* 登录界面 */
export default {
  title: '用戶登錄',
  username: '請輸入登入帳號',
  password: '請輸入登入密碼',
  code: '請輸入驗證碼',
  remember: '記住密碼',
  forget: '忘記密碼',
  login: '登入',
  loading: '登入中'
};
