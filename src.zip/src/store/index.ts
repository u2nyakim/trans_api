/**
 * pinia
 */
import { createPinia } from 'pinia';

export default createPinia();
