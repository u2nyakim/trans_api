/**
 * 搜索表单类型
 */
export interface WhereType {
  keywords?: string;
}
