<template>

</template>

<script>
export default {
  name: "ai-request-search"
}
</script>

<style scoped>

</style>
