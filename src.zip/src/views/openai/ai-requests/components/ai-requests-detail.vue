<template>

</template>

<script>
export default {
  name: "ai-request-detail"
}
</script>

<style scoped>

</style>
