<template>
  <div class="ele-body">
    <a-card :bordered="false">
      <!-- 搜索表单 -->
      <user-wallet-bill-search @search="reload" />
      <!-- 表格 -->
      <ele-pro-table
        ref="tableRef"
        row-key="id"
        :columns="columns"
        :datasource="datasource"
        :scroll="{ x: 900 }"
        cache-key="proSystemLoginRecordTable"
      >
        <template #bodyCell="{ column, record }">
          <template v-if="column.key === 'fundType'">
            <a-tag v-if="record.fundType === 10" color="green">RMB余额</a-tag>
            <a-tag v-else-if="record.fundType === 20" color="orange">
              会话积分
            </a-tag>
          </template>
          <template v-else-if="column.key === 'changeType'">
            <a-tag v-if="record.changeType === 'i'" color="cyan">增加</a-tag>
            <a-tag v-else-if="record.changeType === 'd'" color="purple">
              减少
            </a-tag>
          </template>
        </template>
      </ele-pro-table>
    </a-card>
  </div>
</template>

<script lang="ts" setup>
  import { ref } from 'vue';
  import type { EleProTable } from 'ele-admin-pro/es';
  import type {
    DatasourceFunction,
    ColumnItem
  } from 'ele-admin-pro/es/ele-pro-table/types';
  import { toDateString } from 'ele-admin-pro/es';
  import UserWalletBillSearch from '@/views/openai/ai-user/components/user-wallet-bill-search.vue';
  import { pageUserFundChanges } from '@/api/system/user-fund-change';
  import type { UserFundChangeParam } from '@/api/system/user-fund-change/model';
  import { timeAgo } from 'ele-admin-pro/es/utils/core';
  import { User } from '@/api/system/user/model';

  // 表格实例
  const tableRef = ref<InstanceType<typeof EleProTable> | null>(null);

  // 表格列配置
  const columns = ref<ColumnItem[]>([
    {
      key: 'index',
      width: 48,
      align: 'center',
      fixed: 'left',
      hideInSetting: true,
      customRender: ({ index }) => index + (tableRef.value?.tableIndex ?? 0)
    },
    {
      title: '资产类型',
      key: 'fundType',
      sorter: true,
      showSorterTooltip: false,
      width: 100,
      align: 'left'
    },

    {
      title: '操作前余额',
      dataIndex: 'beforeMoney',
      sorter: false,
      showSorterTooltip: false,
      ellipsis: true,
      width: 160
    },
    {
      title: '操作后余额',
      dataIndex: 'afterMoney',
      sorter: false,
      showSorterTooltip: false,
      ellipsis: true,
      width: 160
    },
    {
      title: '操作金额',
      dataIndex: 'money',
      sorter: false,
      showSorterTooltip: false,
      ellipsis: true,
      width: 160
    },
    {
      title: '操作类型',
      key: 'changeType',
      sorter: true,
      showSorterTooltip: false,
      width: 100,
      align: 'center'
    },
    {
      title: '来源',
      dataIndex: 'source',
      sorter: false,
      showSorterTooltip: false,
      ellipsis: true,
      width: 120
    },
    {
      title: '备注',
      dataIndex: 'reason',
      sorter: false,
      showSorterTooltip: false,
      ellipsis: true
    },
    {
      title: '记录时间',
      dataIndex: 'createTime',
      sorter: false,
      showSorterTooltip: false,
      ellipsis: true,
      customRender: ({ text }) => timeAgo(text),
      width: 160
    },
    {
      title: '创建时间',
      dataIndex: 'createTime',
      sorter: true,
      showSorterTooltip: false,
      ellipsis: true,
      customRender: ({ text }) => toDateString(text),
      width: 160
    }
  ]);

  // 表格数据源
  const datasource: DatasourceFunction = ({
    page,
    limit,
    where,
    orders,
    filters
  }) => {
    where.userId = props.data.userId;
    return pageUserFundChanges({
      ...where,
      ...orders,
      ...filters,
      page,
      limit
    });
  };

  const props = withDefaults(
    defineProps<{
      // 修改回显的数据
      data: User;
    }>(),
    {}
  );

  /* 刷新表格 */
  const reload = (where?: UserFundChangeParam) => {
    tableRef?.value?.reload({ page: 1, where });
  };
  defineExpose({
    reloadTable: () => {
      reload();
    }
  });
</script>
