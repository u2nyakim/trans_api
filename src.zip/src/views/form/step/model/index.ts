export interface StepForm {
  account?: string;
  receiver?: string;
  pay?: string;
  name?: string;
  amount?: number;
}
