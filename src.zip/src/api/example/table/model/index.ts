export interface UserScore {
  id: number;
  userName: string;
  courseName: string;
  score: number;
  userNameRowSpan: number;
}
