export interface UserItem {
  key: string;
  isEdit?: boolean;
  number?: string;
  name?: string;
  department?: string;
}
